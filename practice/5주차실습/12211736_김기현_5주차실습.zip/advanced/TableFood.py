class TableFood:
    def __init__(self, tablenumber: int, foodname: str, totaltime: int):
        self.tablenumber = tablenumber
        self.foodname = foodname
        self.totaltime = totaltime